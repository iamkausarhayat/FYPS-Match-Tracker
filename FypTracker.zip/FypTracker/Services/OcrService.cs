﻿using System.Text;
using Tesseract;
using UglyToad.PdfPig;

namespace FypTracker.Services
{
    // Scanned PDF (CamScanner waghera) ki tasveeron se text parhta hai (OCR).
    // Agar tessdata/eng.traineddata maujood nahi to IsAvailable = false hota hai
    // aur app crash nahi hoti: bas saaf paigham dikhata hai.
    public class OcrService
    {
        private const int MaxCharacters = 20000;   // description ki hadd 3000 hai, itna kaafi hai

        private readonly string _tessDataPath = Path.Combine(AppContext.BaseDirectory, "tessdata");
        private readonly SemaphoreSlim _gate = new(1, 1);   // OCR bhari kaam hai: ek waqt mein ek hi
        private readonly ILogger<OcrService> _logger;

        public OcrService(ILogger<OcrService> logger)
        {
            _logger = logger;
        }

        // Kya English language file maujood hai aur theek lagti hai?
        // Asli eng.traineddata (tessdata_fast) taqreeban 4 MB ki hoti hai. Chhoti file kharab hai.
        public bool IsAvailable
        {
            get
            {
                var file = new FileInfo(Path.Combine(_tessDataPath, "eng.traineddata"));
                return file.Exists && file.Length > 1_000_000;
            }
        }

        public async Task<string> ReadScannedPdfAsync(byte[] pdfBytes, int maxPages)
        {
            if (!IsAvailable)
            {
                return string.Empty;
            }

            await _gate.WaitAsync();
            try
            {
                // OCR CPU par chalta hai, is liye alag thread par taake web server na ruke
                return await Task.Run(() => Run(pdfBytes, maxPages));
            }
            catch (TesseractException ex)
            {
                // Engine shuru na ho (kharab traineddata waghera): app crash nahi, bas log aur khali text
                _logger.LogError(ex, "Tesseract OCR failed. Check that tessdata/eng.traineddata is the real file (about 4 MB).");
                return string.Empty;
            }
            finally
            {
                _gate.Release();
            }
        }

        private string Run(byte[] pdfBytes, int maxPages)
        {
            var text = new StringBuilder();

            using var engine = new TesseractEngine(_tessDataPath, "eng", EngineMode.Default);
            using var pdf = PdfDocument.Open(pdfBytes);

            foreach (var page in pdf.GetPages().Take(maxPages))
            {
                // CamScanner ki har page aam tor par ek bari tasveer hoti hai
                foreach (var image in page.GetImages())
                {
                    try
                    {
                        byte[] bytes = image.TryGetPng(out var png) && png != null
                            ? png
                            : image.RawBytes.ToArray();

                        using var pix = Pix.LoadFromMemory(bytes);
                        using var result = engine.Process(pix);

                        text.AppendLine(result.GetText());
                    }
                    catch (Exception ex)
                    {
                        // ek tasveer na parhi jaye to baqi pages chalte rahen
                        _logger.LogWarning(ex, "OCR could not read one image on page {Page}", page.Number);
                    }
                }

                if (text.Length > MaxCharacters)
                {
                    break;
                }
            }

            return text.ToString();
        }
    }
}